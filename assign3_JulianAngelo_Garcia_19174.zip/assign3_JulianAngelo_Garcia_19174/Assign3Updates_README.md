# Updates

## Style
* Style element has added on style modifiers for code related to assignment 3

## menu.html
* Within each new div menu item, i've added a new line (<input type>), with attributes such as the name, data-price, quantity, which are used in the order.js file to calculate totals and cost
* line 279-303 contain a new block of code pertaining to the total and list of items, acting as a "Cart" function seen on shopping sites, issue with styling through CSS so used in-line styling and works as wanted

## order.js
* commented out on most lines, is a new file pertaining to assignment 3