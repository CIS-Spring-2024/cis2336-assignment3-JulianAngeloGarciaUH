document.addEventListener('DOMContentLoaded', () => {
    // Select all menu category buttons
    const categoryButtons = document.querySelectorAll('.menu-category');

    // Select all menu items
    const menuItems = document.querySelectorAll('.menu-item');

    // Add event listener to each category button
    categoryButtons.forEach(button => {
        button.addEventListener('click', () => {
            // Remove 'active' class from all buttons
            categoryButtons.forEach(btn => btn.classList.remove('active'));

            // Add 'active' class to the clicked button
            button.classList.add('active');

            // Get the category type from the clicked button's data-type attribute
            const categoryType = button.getAttribute('data-type').toLowerCase();

            // Show or hide menu items based on category type
            menuItems.forEach(item => {
                const itemType = item.getAttribute('data-type').toLowerCase();
                if (categoryType === 'all' || categoryType === itemType) {
                    item.style.display = 'block'; // Show menu item
                } else {
                    item.style.display = 'none'; // Hide menu item
                }
            });
        });
    });
});

